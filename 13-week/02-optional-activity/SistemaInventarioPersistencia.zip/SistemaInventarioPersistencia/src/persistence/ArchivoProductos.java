package persistence;

import model.Producto;

import java.io.IOException;
import java.nio.file.*;
import java.util.ArrayList;
import java.util.List;

public class ArchivoProductos {

    private static final String RUTA = "data/productos.csv";

    // Cargar productos
    public List<Producto> cargar() {

        List<Producto> productos = new ArrayList<>();

        Path path = Paths.get(RUTA);

        // Si el archivo no existe
        if (!Files.exists(path)) {

            System.out.println("El archivo no existe. Se iniciará una lista vacía.");

            return productos;
        }

        try {

            List<String> lineas = Files.readAllLines(path);

            for (String linea : lineas) {

                // Ignorar líneas vacías
                if (linea.isBlank()) {
                    continue;
                }

                String[] partes = linea.split(",");

                String codigo = partes[0];
                String nombre = partes[1];
                double precio = Double.parseDouble(partes[2]);

                Producto p = new Producto(codigo, nombre, precio);

                productos.add(p);
            }

        } catch (IOException e) {

            System.out.println("Error al leer el archivo: " + e.getMessage());
        }

        return productos;
    }

    // Guardar productos
    public void guardar(List<Producto> productos) {

        Path path = Paths.get(RUTA);

        try {

            // Crear carpeta si no existe
            Files.createDirectories(path.getParent());

            List<String> lineas = new ArrayList<>();

            for (Producto p : productos) {

                String linea = p.getCodigo() + "," +
                        p.getNombre() + "," +
                        p.getPrecio();

                lineas.add(linea);
            }

            Files.write(
                    path,
                    lineas,
                    StandardOpenOption.CREATE,
                    StandardOpenOption.TRUNCATE_EXISTING
            );

            System.out.println("Productos guardados correctamente.");

        } catch (IOException e) {

            System.out.println("Error al guardar archivo: " + e.getMessage());
        }
    }
}