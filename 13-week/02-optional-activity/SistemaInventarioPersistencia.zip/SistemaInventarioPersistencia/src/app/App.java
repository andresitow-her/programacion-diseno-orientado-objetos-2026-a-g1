package app;

import model.Producto;
import persistence.ArchivoProductos;

import java.util.ArrayList;
import java.util.List;

public class App {

    public static void main(String[] args) {

        ArchivoProductos archivo = new ArchivoProductos();

        // Cargar productos
        List<Producto> productos = archivo.cargar();

        System.out.println("===== PRODUCTOS CARGADOS =====");

        for (Producto p : productos) {
            System.out.println(p);
        }

        // Si está vacío, agregar productos iniciales
        if (productos.isEmpty()) {

            productos.add(new Producto("P001", "Teclado", 120000));
            productos.add(new Producto("P002", "Mouse", 50000));
            productos.add(new Producto("P003", "Monitor", 800000));
            productos.add(new Producto("P004", "Audifonos", 150000));

            System.out.println("\nSe agregaron productos iniciales.");
        }

        // Guardar productos
        archivo.guardar(productos);

        System.out.println("\n===== LISTADO FINAL =====");

        for (Producto p : productos) {
            System.out.println(p);
        }
    }
}