package app;

import exception.ProductoDuplicadoException;
import model.Producto;
import service.Inventario;

public class App {

    public static void main(String[] args) {

        Inventario inventario = new Inventario();

        // =========================
        // PRODUCTO 1
        // =========================
        try {

            Producto p1 = new Producto(
                    "P001",
                    "Teclado Mecánico",
                    180000
            );

            inventario.agregarProducto(p1);

        } catch (IllegalArgumentException | ProductoDuplicadoException e) {

            System.out.println("Error: " + e.getMessage());
        }

        // =========================
        // PRODUCTO 2
        // =========================
        try {

            Producto p2 = new Producto(
                    "P002",
                    "Mouse Gamer",
                    95000
            );

            inventario.agregarProducto(p2);

        } catch (IllegalArgumentException | ProductoDuplicadoException e) {

            System.out.println("Error: " + e.getMessage());
        }

        // =========================
        // PRODUCTO REPETIDO
        // =========================
        try {

            Producto p3 = new Producto(
                    "P001",
                    "Monitor Gamer",
                    800000
            );

            inventario.agregarProducto(p3);

        } catch (IllegalArgumentException | ProductoDuplicadoException e) {

            System.out.println("Error controlado: " + e.getMessage());
        }

        // =========================
        // PRODUCTO CON PRECIO INVÁLIDO
        // =========================
        try {

            Producto p4 = new Producto(
                    "P004",
                    "Audífonos",
                    -5000
            );

            inventario.agregarProducto(p4);

        } catch (IllegalArgumentException | ProductoDuplicadoException e) {

            System.out.println("Error controlado: " + e.getMessage());
        }

        // =========================
        // LISTAR PRODUCTOS
        // =========================
        inventario.listarProductos();

        System.out.println("\nPrograma finalizado correctamente.");
    }
}