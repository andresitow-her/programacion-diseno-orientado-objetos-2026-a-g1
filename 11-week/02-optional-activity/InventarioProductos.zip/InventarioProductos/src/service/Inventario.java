package service;

import exception.ProductoDuplicadoException;
import model.Producto;

import java.util.ArrayList;
import java.util.List;

public class Inventario {

    private List<Producto> productos;

    public Inventario() {
        productos = new ArrayList<>();
    }

    public void agregarProducto(Producto producto) {

        for (Producto p : productos) {

            if (p.getCodigo().equalsIgnoreCase(producto.getCodigo())) {
                throw new ProductoDuplicadoException(producto.getCodigo());
            }
        }

        productos.add(producto);

        System.out.println("Producto agregado correctamente");
    }

    public void listarProductos() {

        System.out.println("\n===== LISTA DE PRODUCTOS =====");

        if (productos.isEmpty()) {
            System.out.println("No hay productos registrados");
            return;
        }

        for (Producto producto : productos) {
            System.out.println(producto);
        }
    }
}