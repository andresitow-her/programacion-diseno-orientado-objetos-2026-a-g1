package com.corhuila.poo.semana6;

public class Persona {

    private String documento;
    private String nombre;
    private String correo;

    public Persona(String documento, String nombre, String correo) {
        setDocumento(documento);
        setNombre(nombre);
        setCorreo(correo);
    }

    public String getDocumento() {
        return documento;
    }

    public void setDocumento(String documento) {
        if (documento == null || documento.trim().isEmpty()) {
            throw new IllegalArgumentException("Documento no puede estar vacío");
        }
        this.documento = documento.trim();
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        if (nombre == null || nombre.trim().isEmpty()) {
            throw new IllegalArgumentException("Nombre no puede estar vacío");
        }
        this.nombre = nombre.trim();
    }

    public String getCorreo() {
        return correo;
    }

    public void setCorreo(String correo) {
        if (correo == null || !correo.contains("@")) {
            throw new IllegalArgumentException("Correo inválido");
        }
        this.correo = correo.trim();
    }

    // Metodo ficha
    public String ficha() {
        return "Persona{documento='" + documento +
                "', nombre='" + nombre +
                "', correo='" + correo + "'}";
    }
}