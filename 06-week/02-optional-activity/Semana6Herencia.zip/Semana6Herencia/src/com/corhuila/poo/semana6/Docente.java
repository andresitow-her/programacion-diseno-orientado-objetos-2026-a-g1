package com.corhuila.poo.semana6;

public class Docente extends Persona {

    private String area;

    public Docente(String documento, String nombre, String correo, String area) {
        super(documento, nombre, correo); // 🔥 herencia
        setArea(area);
    }

    public String getArea() {
        return area;
    }

    public void setArea(String area) {
        if (area == null || area.trim().isEmpty()) {
            throw new IllegalArgumentException("Área no puede estar vacía");
        }
        this.area = area.trim();
    }

    public String fichaDocente() {
        return ficha() + ", Docente{area='" + area + "'}";
    }
}