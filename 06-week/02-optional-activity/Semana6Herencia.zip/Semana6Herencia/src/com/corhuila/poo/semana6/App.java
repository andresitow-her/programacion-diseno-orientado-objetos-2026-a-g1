package com.corhuila.poo.semana6;

public class App {

    public static void main(String[] args) {

        Persona p = new Persona("1010", "Andres Herrera", "andres@gmail.com");

        Docente d = new Docente("2020", "Laura Gomez", "laura@correo.com", "Matemáticas");

        Administrativo a = new Administrativo("3030", "Carlos Ruiz", "carlos@correo.com", "Coordinador");

        System.out.println(p.ficha());
        System.out.println(d.fichaDocente());
        System.out.println(a.fichaAdministrativo());
    }
}