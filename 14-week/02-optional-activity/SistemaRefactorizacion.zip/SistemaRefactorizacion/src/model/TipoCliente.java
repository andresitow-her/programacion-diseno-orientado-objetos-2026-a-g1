package model;

public enum TipoCliente {

    VIP,
    FRECUENTE,
    NORMAL
}