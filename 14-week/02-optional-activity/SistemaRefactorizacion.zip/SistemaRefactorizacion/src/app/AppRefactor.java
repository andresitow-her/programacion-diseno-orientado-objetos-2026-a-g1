package app;

import model.TipoCliente;
import service.CalculadoraService;

public class AppRefactor {

    public static void main(String[] args) {

        double subtotal = 500000;

        boolean aplicarIVA = true;
        boolean aplicarDescuento = true;

        TipoCliente tipoCliente = TipoCliente.VIP;

        CalculadoraService calculadora = new CalculadoraService();

        double total = calculadora.calcularTotal(
                subtotal,
                aplicarIVA,
                aplicarDescuento,
                tipoCliente
        );

        System.out.println("Total: " + total);
    }
}