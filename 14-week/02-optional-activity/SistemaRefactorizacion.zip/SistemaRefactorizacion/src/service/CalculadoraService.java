package service;

import model.TipoCliente;

public class CalculadoraService {

    // Constantes
    private static final double IVA = 0.19;

    private static final double DESCUENTO_VIP = 0.20;
    private static final double DESCUENTO_FRECUENTE = 0.10;
    private static final double DESCUENTO_NORMAL = 0.05;

    public double calcularTotal(
            double subtotal,
            boolean aplicarIVA,
            boolean aplicarDescuento,
            TipoCliente tipoCliente
    ) {

        if (subtotal <= 0) {
            return 0;
        }

        double total = subtotal;

        if (aplicarDescuento) {
            total = aplicarDescuento(total, tipoCliente);
        }

        if (aplicarIVA) {
            total = aplicarIVA(total);
        }

        return redondear(total);
    }

    // Método para descuentos
    private double aplicarDescuento(double total, TipoCliente tipoCliente) {

        switch (tipoCliente) {

            case VIP:
                return total - (total * DESCUENTO_VIP);

            case FRECUENTE:
                return total - (total * DESCUENTO_FRECUENTE);

            default:
                return total - (total * DESCUENTO_NORMAL);
        }
    }

    // Método para IVA
    private double aplicarIVA(double total) {

        return total + (total * IVA);
    }

    // Método para redondear
    private double redondear(double total) {

        return Math.round(total * 100.0) / 100.0;
    }
}