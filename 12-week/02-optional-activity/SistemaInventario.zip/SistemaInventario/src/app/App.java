package app;

import model.Producto;
import service.Inventario;

public class App {

    public static void main(String[] args) {

        Inventario inventario = new Inventario();

        try {

            // Crear productos
            Producto p1 = new Producto("P001", "Teclado", 120000);
            Producto p2 = new Producto("P002", "Mouse", 50000);
            Producto p3 = new Producto("P003", "Monitor", 800000);
            Producto p4 = new Producto("P004", "Audifonos", 150000);

            // Agregar productos
            inventario.agregarProducto(p1);
            inventario.agregarProducto(p2);
            inventario.agregarProducto(p3);
            inventario.agregarProducto(p4);

            // Entradas
            inventario.entrada("P001", 10);
            inventario.entrada("P002", 20);
            inventario.entrada("P003", 5);
            inventario.entrada("P004", 8);

            // Salidas
            inventario.salida("P001", 2);
            inventario.salida("P002", 5);

            // Error de stock
            inventario.salida("P003", 20);

            // Buscar producto
            inventario.buscar("P001");

            // Código inexistente
            inventario.buscar("P999");

            // Reporte final
            inventario.listar();

        } catch (IllegalArgumentException e) {

            System.out.println("Error: " + e.getMessage());
        }
    }
}