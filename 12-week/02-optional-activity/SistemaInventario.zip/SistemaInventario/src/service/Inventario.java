package service;

import model.Producto;

import java.util.HashMap;
import java.util.Map;

public class Inventario {

    private Map<String, Producto> productos;
    private Map<String, Integer> cantidades;

    public Inventario() {

        productos = new HashMap<>();
        cantidades = new HashMap<>();
    }

    // Agregar producto
    public void agregarProducto(Producto p) {

        if (productos.containsKey(p.getCodigo())) {
            System.out.println("Error: el código ya existe");
            return;
        }

        productos.put(p.getCodigo(), p);
        cantidades.put(p.getCodigo(), 0);

        System.out.println("Producto agregado correctamente");
    }

    // Entrada de stock
    public void entrada(String codigo, int cantidad) {

        if (!productos.containsKey(codigo)) {
            System.out.println("Error: producto no encontrado");
            return;
        }

        if (cantidad <= 0) {
            System.out.println("La cantidad debe ser mayor que 0");
            return;
        }

        int stockActual = cantidades.get(codigo);

        cantidades.put(codigo, stockActual + cantidad);

        System.out.println("Entrada registrada");
    }

    // Salida de stock
    public void salida(String codigo, int cantidad) {

        if (!productos.containsKey(codigo)) {
            System.out.println("Error: producto no encontrado");
            return;
        }

        if (cantidad <= 0) {
            System.out.println("La cantidad debe ser mayor que 0");
            return;
        }

        int stockActual = cantidades.get(codigo);

        if (cantidad > stockActual) {
            System.out.println("Error: stock insuficiente");
            return;
        }

        cantidades.put(codigo, stockActual - cantidad);

        System.out.println("Salida registrada");
    }

    // Buscar producto
    public void buscar(String codigo) {

        if (!productos.containsKey(codigo)) {
            System.out.println("Producto no encontrado");
            return;
        }

        Producto p = productos.get(codigo);

        System.out.println(p);
        System.out.println("Stock: " + cantidades.get(codigo));
    }

    // Listar productos
    public void listar() {

        System.out.println("\n===== REPORTE FINAL =====");

        for (String codigo : productos.keySet()) {

            Producto p = productos.get(codigo);

            System.out.println(p);
            System.out.println("Cantidad: " + cantidades.get(codigo));
            System.out.println("--------------------------");
        }
    }
}