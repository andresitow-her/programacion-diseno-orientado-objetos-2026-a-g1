package com.corhuila.poo.semana7;

import java.util.ArrayList;
import java.util.List;

public class App {
    public static void main(String[] args) {
        List<Envio> listaEnvios = new ArrayList<>();

        // Agregamos diferentes tipos de envíos a la misma lista
        listaEnvios.add(new EnvioEstandar("EST-001", 5.0));
        listaEnvios.add(new EnvioExpress("EXP-002", 2.5));
        listaEnvios.add(new EnvioInternacional("INT-003", 10.0, "España"));

        double costoTotal = 0;

        System.out.println("--- RESUMEN DE ENVÍOS ---");
        for (Envio e : listaEnvios) {
            // POLIMORFISMO: Se llama al calcularCosto() correspondiente a la subclase
            System.out.println(e.resumen());
            costoTotal += e.calcularCosto();
        }

        System.out.println("-------------------------");
        System.out.println("TOTAL A PAGAR: $" + costoTotal);
    }
}