package com.corhuila.poo.semana7;

public class EnvioInternacional extends Envio {
    private String paisDestino;

    public EnvioInternacional(String codigo, double pesoKg, String paisDestino) {
        super(codigo, pesoKg);
        this.paisDestino = paisDestino;
    }

    @Override
    public double calcularCosto() {
        return 30000 + (getPesoKg() * 6000);
    }

    @Override
    public String resumen() {
        return super.resumen() + " [Destino: " + paisDestino + "]";
    }
}