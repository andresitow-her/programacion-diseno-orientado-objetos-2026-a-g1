package App;

import Model.Libro;
import Service.Biblioteca;

import java.util.Scanner;

public class app {

    public static void main(String[] args) {

        Biblioteca biblioteca = new Biblioteca();
        Scanner sc = new Scanner(System.in);

        int opcion;

        do {

            System.out.println("\n===== BIBLIOTECA =====");
            System.out.println("1. Registrar libro");
            System.out.println("2. Listar libros");
            System.out.println("3. Listar disponibles");
            System.out.println("4. Buscar por código");
            System.out.println("5. Prestar libro");
            System.out.println("6. Devolver libro");
            System.out.println("7. Salir");

            System.out.print("Seleccione opción: ");
            opcion = sc.nextInt();
            sc.nextLine();

            switch (opcion) {

                case 1:

                    System.out.print("Código: ");
                    String codigo = sc.nextLine();

                    System.out.print("Título: ");
                    String titulo = sc.nextLine();

                    System.out.print("Autor: ");
                    String autor = sc.nextLine();

                    System.out.print("Año: ");
                    int anio = sc.nextInt();
                    sc.nextLine();

                    try {

                        Libro libro = new Libro(codigo, titulo, autor, anio, true);

                        if (biblioteca.agregarLibro(libro)) {
                            System.out.println("Libro registrado.");
                        } else {
                            System.out.println("Ya existe un libro con ese código.");
                        }

                    } catch (Exception e) {
                        System.out.println("Error: " + e.getMessage());
                    }

                    break;

                case 2:
                    biblioteca.listarLibros();
                    break;

                case 3:
                    biblioteca.listarDisponibles();
                    break;

                case 4:

                    System.out.print("Código del libro: ");
                    String buscar = sc.nextLine();

                    Libro libro = biblioteca.buscarPorCodigo(buscar);

                    if (libro == null) {
                        System.out.println("Libro no encontrado.");
                    } else {
                        System.out.println(libro);
                    }

                    break;

                case 5:

                    System.out.print("Código del libro a prestar: ");
                    String prestamo = sc.nextLine();

                    biblioteca.prestarLibro(prestamo);

                    break;

                case 6:

                    System.out.print("Código del libro a devolver: ");
                    String devolucion = sc.nextLine();

                    biblioteca.devolverLibro(devolucion);

                    break;

                case 7:
                    System.out.println("Saliendo...");
                    break;

                default:
                    System.out.println("Opción inválida.");

            }

        } while (opcion != 7);
    }
}