package Model;

public class Libro {

    private String codigo;
    private String titulo;
    private String autor;
    private int anio;
    private boolean disponible;


    public Libro(String codigo, String titulo, String autor, int anio, boolean disponible) {
        setCodigo(codigo);
        setTitulo(titulo);
        setAutor(autor);
        setAnio(anio);
        this.disponible = disponible;
    }


    public Libro(String codigo, String titulo, String autor) {
        setCodigo(codigo);
        setTitulo(titulo);
        setAutor(autor);
        this.anio = 0;
        this.disponible = true;
    }



    public String getCodigo() {
        return codigo;
    }

    public void setCodigo(String codigo) {
        if (codigo == null || codigo.isEmpty()) {
            throw new IllegalArgumentException("El código no puede estar vacío");
        }
        this.codigo = codigo;
    }

    public String getTitulo() {
        return titulo;
    }

    public void setTitulo(String titulo) {
        if (titulo == null || titulo.isEmpty()) {
            throw new IllegalArgumentException("El título no puede estar vacío");
        }
        this.titulo = titulo;
    }

    public String getAutor() {
        return autor;
    }

    public void setAutor(String autor) {
        if (autor == null || autor.isEmpty()) {
            throw new IllegalArgumentException("El autor no puede estar vacío");
        }
        this.autor = autor;
    }

    public int getAnio() {
        return anio;
    }

    public void setAnio(int anio) {
        if (anio < 0) {
            throw new IllegalArgumentException("El año no puede ser negativo");
        }
        this.anio = anio;
    }

    public boolean isDisponible() {
        return disponible;
    }



    public boolean prestar() {
        if (!disponible) {
            return false;
        }
        disponible = false;
        return true;
    }

    public boolean devolver() {
        if (disponible) {
            return false;
        }
        disponible = true;
        return true;
    }

    @Override
    public String toString() {
        return "Código: " + codigo +
                " | Título: " + titulo +
                " | Autor: " + autor +
                " | Año: " + anio +
                " | Disponible: " + (disponible ? "Sí" : "No");
    }
}