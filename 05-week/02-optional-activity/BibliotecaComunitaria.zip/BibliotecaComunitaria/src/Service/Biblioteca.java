package Service;

import Model.Libro;
import java.util.ArrayList;

public class Biblioteca {

    private ArrayList<Libro> libros;

    public Biblioteca() {
        libros = new ArrayList<>();
    }

    public boolean agregarLibro(Libro libro) {

        if (buscarPorCodigo(libro.getCodigo()) != null) {
            return false;
        }

        libros.add(libro);
        return true;
    }

    public Libro buscarPorCodigo(String codigo) {

        for (Libro l : libros) {
            if (l.getCodigo().equalsIgnoreCase(codigo)) {
                return l;
            }
        }

        return null;
    }

    public void listarLibros() {

        if (libros.isEmpty()) {
            System.out.println("No hay libros registrados.");
            return;
        }

        for (Libro l : libros) {
            System.out.println(l);
        }
    }

    public void listarDisponibles() {

        boolean hay = false;

        for (Libro l : libros) {
            if (l.isDisponible()) {
                System.out.println(l);
                hay = true;
            }
        }

        if (!hay) {
            System.out.println("No hay libros disponibles.");
        }
    }

    public void prestarLibro(String codigo) {

        Libro libro = buscarPorCodigo(codigo);

        if (libro == null) {
            System.out.println("El libro no existe.");
            return;
        }

        if (!libro.prestar()) {
            System.out.println("El libro ya está prestado.");
        } else {
            System.out.println("Libro prestado correctamente.");
        }
    }

    public void devolverLibro(String codigo) {

        Libro libro = buscarPorCodigo(codigo);

        if (libro == null) {
            System.out.println("El libro no existe.");
            return;
        }

        if (!libro.devolver()) {
            System.out.println("El libro ya está disponible.");
        } else {
            System.out.println("Libro devuelto correctamente.");
        }
    }
}